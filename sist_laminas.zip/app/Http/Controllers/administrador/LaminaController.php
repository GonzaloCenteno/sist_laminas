<?php

namespace App\Http\Controllers\administrador;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tbllmna;
use App\Models\Tblctga;
use App\Http\Requests\TbllmnaRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class LaminaController extends Controller
{
    public function index()
    {
        return view('administrador.lamina.index', [
            'categorias' => Tblctga::get()
        ]);
    }

    public function create()
    {
        //
    }

    public function store(TbllmnaRequest $request)
    {
        if(!$request->ajax()) return redirect('/');
        $request['tbllmnauuid'] = Str::random(12);
        $request['tbllmnafech'] = date('Y-m-d');
        Tbllmna::create($request->all());
        return response()->json(['success' => 'success'], 200);
    }

    public function show(Request $request,$id)
    {
        return datatables()->of(Tbllmna::with('categoria')->get())
            ->addColumn('action', function ($c) {
                if($c->tbllmnalmrd == 1):
                        $cheked = '<div class="form-check">
                            <input type="checkbox" style="height:25px; width:50%" onChange="cambiarEstado('.$c->tbllmnacdgo.',0)" class="form-check-input pt-0 mt-0" id="check_'.$c->tbllmnacdgo.'">
                            <label class="form-check-label" for="check_'.$c->tbllmnacdgo.'"></label>
                        </div>';
                else:
                        $cheked ='<div class="form-check">
                            <input type="checkbox" style="height:25px; width:50%" checked onChange="cambiarEstado('.$c->tbllmnacdgo.',1)" class="form-check-input pt-0 mt-0" id="check_'.$c->tbllmnacdgo.'">
                            <label class="form-check-label" for="check_'.$c->tbllmnacdgo.'"></label>
                        </div>';
                endif;
                return $cheked;
            })->make(true);
    }

    public function edit(Request $request,$id)
    {
        if(!$request->ajax()) return redirect('/');
        Tbllmna::where('tbllmnacdgo',$id)->update([ 'tbllmnalmrd' => $request->tipo ]);
        return response()->json(['success' => 'success'], 200);
    }

    public function update(TbllmnaRequest $request, $are_id)
    {
        
    }

    public function destroy($id)
    {
        //
    }
}
