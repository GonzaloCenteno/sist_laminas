<div class="container py-5">
    <div class="row">
        <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
            <div class="card shadow-lg text-center" style="width: 22rem;border-radius: 30px; !important">
                <div class="card-body text-center">
                    <div class="col-12 py-3">
                        <img src="<?php echo e(asset('img/plan'.$key.'.png')); ?>" height="150" class="d-inline-block align-top">
                    </div>
                    <h2 class="card-tittle font-weight-bold"><?php echo e($plan->tblplanprdo); ?> Meses</h2>
                    <h6 class="card-subtitle mb-2 text-muted">Suscripcion</h6>
                    <p class="card-title pt-3 pb-5"><span class="font-weight-bold h1">s/<?php echo e($plan->tblplancost); ?></span> <span>/<?php echo e($plan->tblplanprdo); ?> meses</span></p>
                    <p class="font-weight-bold h3 pb-3"><?php echo e($plan->tblplannomb); ?></p>
                    <p class="card-text"><?php echo e($plan->tblplandesc); ?></p>
                    <p class="card-text"><?php echo e($plan->tblplanprdo); ?> meses</p>
                    <p class="card-text">24/7 Soporte</p>
                    <div class="row">
                        <div class="col">
                            <a class="btn btn-rounded btn-outline-danger waves-effect nav-link" href="<?php echo e(url('login')); ?>">
                                <span>SUSCRIBIRSE</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sist_laminas\resources\views/principal/components/plan.blade.php ENDPATH**/ ?>