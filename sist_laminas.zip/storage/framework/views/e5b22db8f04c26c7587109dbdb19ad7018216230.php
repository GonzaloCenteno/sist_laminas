<?php $__env->startSection('content-login'); ?>
    <div class="card shadow-lg p-3 mb-5 bg-white wow animated fadeInDown" style="border-radius: 25px; !important">
        <h5 class="card-header shadow white-text text-center py-3" style="background-color: #fff;border-radius: 25px; !important">
            <img src="<?php echo e(asset('img/logo-parrot.png')); ?>" class="img-fluid">
        </h5>
        <div class="card-body px-5 mx-3">
            <div class="row">
                <div class="col-5">
                    <img src="<?php echo e(asset('img/parrot.png')); ?>" class="img-fluid">
                </div>
                <div class="col-7">
                    <p class="h4 mb-2 text-center">INICIAR SESION</p>
                    <form method="POST" action="<?php echo e(route('login')); ?>" class="text-center" style="color: #757575;" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="md-form md-outline form-sm input-with-pre-icon">
                            <i class="fa fa-user input-prefix"></i>
                            <input type="text" id="email" name="email" autocomplete="off" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-danger is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" autofocus>
                            <label for="email">Usuario</label>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="md-form md-outline form-sm input-with-pre-icon">
                            <i class="fa fa-lock input-prefix"></i>
                            <input type="password" id="password" name="password" autocomplete="off" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-danger is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="password">Contraseña</label>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <button type="submit" class="btn btn-sm btn-outline-primary btn-rounded btn-block waves-effect">ACEPTAR</button>
                            </div>
                            <div class="col-6">
                                <a class="btn btn-sm btn-outline-primary btn-rounded btn-block waves-effect" href="<?php echo e(route('register')); ?>">REGISTRAR</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sist_laminas\resources\views/auth/login.blade.php ENDPATH**/ ?>