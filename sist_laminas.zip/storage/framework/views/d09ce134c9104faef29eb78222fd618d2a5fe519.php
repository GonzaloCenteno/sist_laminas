
<?php $__env->startSection('title', ' - Mis Laminas'); ?> 
<?php $__env->startSection('content'); ?>

<style>
    .imglam {
        max-height: 250px;
    }
</style>

<div class="container-fluid">
    <?php if($laminas->count() != 0): ?>
    <div class="row">
        <div class="col-7">
            <div class="md-form md-outline form-sm">
                <input type="text" id="bsq_lamina" name="bsq_lamina" autocomplete="off" class="form-control" autofocus>
                <label for="bsq_lamina">BUSCAR LAMINA.-</label>
            </div>
        </div>
        <div class="col-5 pt-4">
            <select class="browser-default custom-select" id="tblctgacdgo" name="tblctgacdgo" onchange="buscar_laminas(this)">
                <option value="0" selected>..:: SELECCIONAR CATEGORIA ::..</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria->tblctgacdgo); ?>"><?php echo e($categoria->tblctgadesc); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small id="error_tblctgacdgo" class="form-text text-muted text-left text-red"></small>
        </div>
    </div>
    <?php endif; ?>
    <div class="row" id="dataLamina">
        <?php echo $__env->make('usuario.file.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php $__env->startSection('page-js-script'); ?>
<script>
    $(document).ready(function(){
        $(document).on('click', '.pagination a', function(event){
            event.preventDefault(); 
            var page = $(this).attr('href').split('page=')[1];
            
            cambiar_pagina(page);
        });
    });

    function cambiar_pagina(page)
    {
        $.ajax({
            url: '<?php echo e(route('file.index')); ?>',
            data: {
                page : page
            },
            success:function(data)
            {
                $('#dataLamina').html(data);
                swal.close();
            }
        });
    }

    function delay(fn, ms) {
        let timer = 0
        return function(...args) {
            clearTimeout(timer)
            timer = setTimeout(fn.bind(this, ...args), ms || 0)
        }
    }

    $("#bsq_lamina").keyup(delay(function (e) {
        if ($(this).val().length > 4) 
        {
            $.ajax({
                url: '<?php echo e(route('file.show',1)); ?>',
                data: {
                    tipo : 2,
                    descripcion: $(this).val()
                },
                success:function(data)
                {
                    $('#dataLamina').html(data);
                    swal.close();
                }
            });
        }
        if($(this).val().length == 0)
        {
            cambiar_pagina(1);
        }
    }, 350));  

    function buscar_laminas(el)
    {
        if(el.value == 0) {
            cambiar_pagina(1);
        } else {
            $.ajax({
                url: '<?php echo e(route('file.show',1)); ?>',
                data: {
                    tipo : 4,
                    valor: el.value
                },
                success:function(data)
                {
                    $('#dataLamina').html(data);
                    swal.close();
                }
            });
        }
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sist_laminas\resources\views/usuario/file/index.blade.php ENDPATH**/ ?>