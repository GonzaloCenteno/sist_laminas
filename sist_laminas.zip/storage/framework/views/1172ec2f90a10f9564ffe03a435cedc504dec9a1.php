
<?php $__env->startSection('title', ' - Ver Mas'); ?> 
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row py-2">
        <div class="col text-center">
            <h2><?php echo e($lamina->tbllmnacoda); ?> - <?php echo e($lamina->tbllmnanomb); ?></h2>
        </div>
    </div>
    <div class="row">
        <div class="col text-center">
            <h2><?php echo e($lamina->categoria->tblctgadesc); ?></h2>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <img src="<?php echo e(asset($lamina->tbllmnaimgn)); ?>" style="width:100%">
        </div>
    </div>
    <div class="row pt-2">
        <div class="col">
            <h2>DESCRIPCION: </h2>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <h4><?php echo e($lamina->tbllmnadesc); ?></h4>
        </div>
    </div>
    <div class="row pt-2">
        <div class="col">
            <h2>TAGS: </h2>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <h4><?php echo e($lamina->tbllmnatags); ?></h4>
        </div>
    </div>
    <div class="row pt-3">
        <div class="col">
            <a type="button" href="<?php echo e(route('file.index')); ?>" class="btn btn-md btn-outline-danger btn-rounded waves-effect btn-block">REGRESAR</a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sist_laminas\resources\views/usuario/file/view.blade.php ENDPATH**/ ?>