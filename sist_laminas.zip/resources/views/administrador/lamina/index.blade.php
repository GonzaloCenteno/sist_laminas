@extends('layouts.app')
@section('title', ' - Laminas') 
@section('content')

<div class="container pt-5">
    <div class="row">
        <div id="registroLamina" class="col d-none">
            <form id="FormularioCrearLamina" method="POST" action="{{ route('lamina.store') }}" class="text-center" novalidate>
                @csrf
                <div class="row">
                    <div class="col-3">
                        <div class="md-form md-outline form-sm">
                            <input type="text" id="tbllmnacoda" name="tbllmnacoda" autocomplete="off" class="form-control" autofocus>
                            <label for="tbllmnacoda">CODIGO LAMINA.-</label>
                            <small id="error_tbllmnacoda" class="form-text text-muted text-left text-red"></small>
                        </div>
                    </div>
                    <div class="col-9">
                        <div class="md-form md-outline form-sm">
                            <input type="text" id="tbllmnanomb" name="tbllmnanomb" autocomplete="off" class="form-control">
                            <label for="tbllmnanomb">NOMBRE.-</label>
                            <small id="error_tbllmnanomb" class="form-text text-muted text-left text-red"></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <label for="tbllmnanomb">IMAGEN ORIGINAL.-</label>
                        <div class="md-form md-outline form-sm mt-0">
                            <input type="file" id="tbllmnaimgo" name="tbllmnaimgo" autocomplete="off" class="form-control" accept="image/png,image/gif,image/jpeg">
                            <small id="error_tbllmnaimgo" class="form-text text-muted text-left text-red"></small>
                        </div>
                    </div>
                    <div class="col-4">
                        <label for="tbllmnanomb">IMAGEN FREE.-</label>
                        <div class="md-form md-outline form-sm mt-0">
                            <input type="file" id="tbllmnaimgf" name="tbllmnaimgf" autocomplete="off" class="form-control" accept="image/png,image/gif,image/jpeg">
                            <!-- <small id="error_tbllmnaimgf" class="form-text text-muted text-left text-red"></small> -->
                        </div>
                    </div>
                    <div class="col-4">
                        <label for="tbllmnanomb">CARATULA POSTERIOR.-</label>
                        <div class="md-form md-outline form-sm mt-0">
                            <input type="file" id="tbllmnapdfl" name="tbllmnapdfl" autocomplete="off" class="form-control" accept="application/pdf">
                            <!-- <small id="error_tbllmnapdfl" class="form-text text-muted text-left text-red"></small> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="md-form md-outline">
                            <textarea id="tbllmnadesc" name="tbllmnadesc" class="md-textarea form-control" rows="3"></textarea>
                            <small id="error_tbllmnadesc" class="form-text text-muted text-left text-red"></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="md-form md-outline">
                            <textarea id="tbllmnatags" name="tbllmnatags" class="md-textarea form-control" rows="3"></textarea>
                            <label for="tbllmnatags">TAGS</label>
                            <small id="error_tbllmnatags" class="form-text text-muted text-left text-red"></small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <select style="width: 100%" id="tblctgacdgo" name="tblctgacdgo[]" multiple="multiple">
                            @foreach($categorias as $categoria)
                                <option value="{{ $categoria->tblctgacdgo }}">{{ $categoria->tblctgadesc }}</option>
                            @endforeach
                        </select>
                        <small id="error_tblctgacdgo" class="form-text text-muted text-left text-red"></small>
                    </div>
                </div>
                <div class="row pt-4">
                    <div class="col-6 offset-2">
                        <button type="submit" class="btn btn-sm btn-outline-primary btn-rounded btn-block waves-effect">GUARDAR</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="container">
            <div class="row justify-content-md-center">
                <div class="col col-lg-2 text-center">
                    <i id="mostrarLamina" class="fa fa-plus-circle fa-4x" aria-hidden="true" style="cursor: pointer"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 mx-0 px-0">
            <table class="table table-sm display nowrap" id="tbllamina" style="width:100%">
                <thead>
                    <tr>
                        <th scope="col">CODIGO LAMINA</th>
                        <th scope="col">CATEGORIA</th>
                        <th scope="col">NOMBRE</th>
                        <th scope="col">FECHA CREACION</th>
                        <th scope="col">RECOMENDADA</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th scope="col"><b>CODIGO LAMINA</b></th>
                        <th scope="col"><b>CATEGORIA</b></th>
                        <th scope="col"><b>NOMBRE</b></th>
                        <th scope="col"><b>FECHA CREACION</b></th>
                        <th scope="col"><b>RECOMENDADA</b></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

@section('page-js-script')
<script>
    jQuery(document).ready(function($){
        CKEDITOR.replace('tbllmnadesc');
        $('#tblctgacdgo').select2({
            placeholder: "..:: SELECCIONAR CATEGORIAS ::.."
        });
    });

    $("#tbllamina").DataTable({
        lengthMenu: [[10, 20, 30, -1], [10, 20, 30, "Todo"]],
        info: true,
        ordering: true,
        destroy:true,
        searching: true,
        // responsive: true,
        // scrollY: "250px",
        // scrollX: true,
        scrollCollapse: true,
        ajax:  '{{ route('lamina.show',1) }}',
        order: [[ 0, "desc" ]],
        columns: [
            { data: 'tbllmnacoda', class:'text-center'},
            { data: 'categoria.tblctgadesc' },
            { data: 'tbllmnanomb' },
            { data: 'tbllmnafech', class:'text-center',orderable: false,searchable: false},
            { data: 'action', class:'text-center',orderable: false,searchable: false},
        ],
        select: true,
        "language": {
            "sSearch": "Buscar por Codigo y/o Nombre",
            "processing": "Cargando Informacion",
            "lengthMenu": "Mostrando _MENU_ Registros Por Pagina",
            "zeroRecords": "No Se Encontro Resultados",
            "info": "Mostrando Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No Se Encontro Resultados",
            select: { rows: "" },
            paginate: {
                previous: 'Anterior',
                next:     'Siguiente'
            }
        }
    });

    $("#mostrarLamina").click(function(){
        $("#registroLamina").removeClass('d-none');
        $("#registroLamina").addClass('d-block');
    });

    //$("#material").addClass("active");

    $("#tbllmnacoda, #tbllmnanomb, #tbllmnaimgo, #tbllmnadesc, #tbllmnatags, #tblctgacdgo, #tbllmnatipo").on('focus', function () {
        limpiarErrores($(this).attr('id'));
    });

    $('#FormularioCrearLamina').submit(function(e){
        e.preventDefault();

        var FormularioRegistro = new FormData($(this)[0]);
        FormularioRegistro.append('tbllmnadesc', CKEDITOR.instances.tbllmnadesc.getData());
        
        for ( instance in CKEDITOR.instances )
            CKEDITOR.instances[instance].updateElement();

        $.ajax({
            url: $(this).attr('action'),
            type: $(this).attr('method'),
            dataType: 'json',
            data: FormularioRegistro,
            processData: false,
            contentType: false,
            success: function (data) 
            {
                $("#tbllmnacoda").val('');
                $("#tbllmnanomb").val('');
                $("#tbllmnaimgo").val('');
                CKEDITOR.instances['tbllmnadesc'].setData('');
                $("#tbllmnatags").val('');
                $("#tblctgacdgo").val(0);
                $("#tbllmnatipo").val(0);
                $("#registroLamina").removeClass('d-block');
                $("#registroLamina").addClass('d-none');
                $('#tbllamina').DataTable().ajax.reload();
                alertas(4);
            }
        });
    });

    function cambiarEstado(cdgo,tipo)
    {
        let url = "{{ route('lamina.edit', 'id') }}";
                url = url.replace('id', cdgo);

        $.ajax({
            type: 'GET',
            url: url,
            data:{
                tipo:tipo
            },
            success: function (data) 
            {
                $('#tbllamina').DataTable().ajax.reload();
                alertas(4);
            }
        });
    }
</script>
@stop
@endsection